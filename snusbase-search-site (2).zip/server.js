
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.SNUSBASE_API_KEY;

app.use(cors());
app.use(express.static('public'));

app.get('/search', async (req, res) => {
    const query = req.query.q;
    if (!query) return res.status(400).json({ error: 'Missing query' });

    try {
        const response = await fetch(`https://api.snusbase.com/v1/search?query=${query}&api_key=${API_KEY}`);
        const data = await response.json();
        res.json(data);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to fetch from Snusbase' });
    }
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));


document.getElementById('searchForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const query = document.getElementById('searchQuery').value;
    document.getElementById('results').innerHTML = 'Searching...';
    fetch(`/search?q=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => displayResults(data))
        .catch(err => {
            console.error(err);
            document.getElementById('results').innerHTML = 'Error fetching results';
        });
});

function displayResults(data) {
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '';
    
    if (!data.results || data.results.length === 0) {
        resultsDiv.innerHTML = '<p>No results found.</p>';
        return;
    }

    data.results.forEach(entry => {
        const div = document.createElement('div');
        div.className = 'result-item';
        div.innerHTML = `
            <strong>Username:</strong> ${entry.username || 'N/A'}<br>
            <strong>Email:</strong> ${entry.email || 'N/A'}<br>
            <strong>IP:</strong> ${entry.ip || 'N/A'}<br>
            <strong>Info:</strong> ${entry.additional_info || 'None'}
        `;
        resultsDiv.appendChild(div);
    });
}
